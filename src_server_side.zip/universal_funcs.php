<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

# TODO: close_db_connection

function response_error($message) {
	$tmp = new stdClass();
	$tmp->response_code = "error";
	$tmp->message = $message;
	die(json_encode($tmp));
} 


function response_success($message) {
	$tmp = new stdClass();
	$tmp->response_code = "success";
	$tmp->message = $message;
	die(json_encode($tmp));
}


function check_json_data(){
	$post_body = file_get_contents('php://input');

	try {
		$post_body = json_decode($post_body, true);
	}catch(Exception $e){
		response_error("Not json data");
	}

	return $post_body;
}

function check_http_method($method) {
	if ($_SERVER['REQUEST_METHOD'] !== $method){
		response_error("Not available http method");
	}
}

function check_get_request() {
	check_http_method("GET");
}

function check_post_and_get_json() {
	check_http_method("POST");
	
	$post_body = check_json_data();
	return $post_body;
}


function if_logged_in_set_session($post_body){
	if (array_key_exists("sessionId", $post_body)){
		session_id($post_body["sessionId"]);
		session_start();
		if (isset($_SESSION["isLoggedIn"]) && $_SESSION["isLoggedIn"]){
			return true;
		}else{
			response_error("You need to log in first");
		}
	}else{
		response_error("No valid sessionId exists in your request.");
	}

}
