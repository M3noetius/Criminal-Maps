<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include("../universal_funcs.php");

$post_body = check_post_and_get_json();
if_logged_in_set_session($post_body);

include("../connect_db.php");


function get_categories($conn){
	$sql_query = "SELECT id, category FROM categories;" ;
	if ($sth = $conn->query($sql_query)) {

		$row = $sth->fetch_all(MYSQLI_ASSOC);
		return $row;
	}else{
		return "Error while preparing query in fetching categories";
	}
}

$output = get_categories($conn);
if (is_array($output)){
	response_success($output);
}else{
	$message = $output;
}

response_error($message);