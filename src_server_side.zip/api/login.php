<?php 
include("../universal_funcs.php");

$post_body = check_post_and_get_json();

include("../connect_db.php");
session_start();
$_SESSION["isLoggedIn"] = false;

function login($conn, $username, $password){
	$sql_query = "SELECT id FROM users WHERE username=? and password=?" ;
	if ($stmt = $conn->prepare($sql_query)) {
		$stmt->bind_param("ss", $username, $password);
		if ($stmt->execute()){
			$stmt->bind_result($returned_id);
			$stmt->store_result();
			$stmt->fetch();
			
			if ($stmt->num_rows === 1){
				return $returned_id;
			}else if ($stmt->num_rows === 0){
				return "Wrong username or password";
			}else{
				return "Unexpected number of returned results";
			}
		}else{
			return "Stmt not executed";
		}
	}else{
		return "Prepare failed: (" . $conn->errno . ") " . $conn->error;
	}

}



if (array_key_exists("username", $post_body) && array_key_exists("password", $post_body)) {
	$username = $post_body["username"];
	$password = $post_body["password"];
	if(!empty(trim($username))) {
		if(!empty(trim($password))) {
			
			$login = login($conn, $username, $password);
			if (is_int($login)){
				$_SESSION["isLoggedIn"] = true;
				$_SESSION["user_id"] = $login;

				response_success(session_id());
			}else{
				$error_message = ($login);
			}
		}else{
	    	$error_message  = "Please enter a password";
		}
	}else{
		$error_message = "Please enter a username.";
	}
}else{
	$error_message = "Username or password field does not exist";	
}

response_error($error_message);

