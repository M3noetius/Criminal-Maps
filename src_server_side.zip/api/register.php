<?php
include("../universal_funcs.php");

$post_body = check_post_and_get_json();

include("../connect_db.php");

// TODO check ddos for users

function register($conn, $username, $password){
	$sql_query = "SELECT id FROM users WHERE username=?" ;
	if ($stmt = $conn->prepare($sql_query)) {
		$stmt->bind_param("s", $username);
		if ($stmt->execute()){
			$stmt->bind_result($returned_id);
			$stmt->store_result();
			$stmt->fetch();
			
			if ($stmt->num_rows === 0){
				$sql_query = "INSERT INTO users (username, password) values (?, ?)" ;
				if ($stmt = $conn->prepare($sql_query)) {
					$stmt->bind_param("ss", $username, $password);
					if ($stmt->execute()){
						return 1;
					}else{
						return "Error while adding user";
					}
				}else{
					return "Error while preparing user";
				}
			}else{
				return "User already exists";
			}
		}else{
			return "Stmt not executed";
		}
	}else{
		return "Prepare failed: (" . $conn->errno . ") " . $conn->error;
	}

}

if (array_key_exists("username", $post_body) && array_key_exists("password", $post_body)) {
	$username = $post_body["username"];
	$password = $post_body["password"];
	if(!empty(trim($username))) {
		if(!empty(trim($password))) {
			
			$register = register($conn, $username, $password);
			if (is_int($register)){
				response_success("Successfully registered user " . $username);
			}else{
				$error_message = $register;
			}
		}else{
	    	$error_message  = "Please enter a password";
		}
	}else{
		$error_message = "Please enter a username.";
	}
}else{
	$error_message = "Username or password field does not exist";	
}

response_error($error_message);