<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include("../universal_funcs.php");

$post_body = check_post_and_get_json();
if_logged_in_set_session($post_body);

include("../connect_db.php");


function get_last_crime_id($conn){
	$sql_query = "SELECT * FROM crimes ORDER BY id DESC LIMIT 1" ;
	if ($result = $conn->query($sql_query)) {
		$row = $result->fetch_row();
		return intval($row[0]);
	}else{
		return "Error while preparing query in fetching crime id";
	}
}

function combine_crime_to_category($conn, $crime_id, $category_id){
	$sql_query = "INSERT INTO crime_is_category (crime_id, category_id) values (?, ?)" ;
	if ($stmt = $conn->prepare($sql_query)) {
		$stmt->bind_param("dd", $crime_id, $category_id);
		if ($stmt->execute()){
			return True;
		}else{
			return "Error while fetching this crime id";
		}
	}else{
		return "Error while preparing query in connecting crime to category";
	}
}


function combine_user_to_crime($conn, $crime_id, $user_id){
	$sql_query = "INSERT INTO user_created_crime (crime_id, user_id) values (?, ?)" ;
	if ($stmt = $conn->prepare($sql_query)) {
		$stmt->bind_param("dd", $crime_id, $user_id);
		if ($stmt->execute()){
			return True;
		}else{
			return "Error while combine_user_to_crime";
		}
	}else{
		return "Error while preparing query in combine_user_to_crime";
	}
}


function add_crime($conn, $longitude, $latitude, $report, $title, $date, $category_id, $user_id){
	$sql_query = "INSERT INTO crimes (longitude, latitude, report, title, date) values (?, ?, ?, ?, ?)" ;
	if ($stmt = $conn->prepare($sql_query)) {
		$stmt->bind_param("ddsss", $longitude, $latitude, $report, $title, $date);
		if ($stmt->execute()){
			$crime_id = get_last_crime_id($conn);
			if (!is_int($crime_id)){
				return $crime_id;
			}
			$output = combine_crime_to_category($conn, $crime_id, $category_id);
			if ( $output === True){
				$output = combine_user_to_crime($conn, $crime_id, $user_id);
				if ($output === True ){
					return True;
				}else{
					return $output;	
				}
			}else{
				return $output;
			}
		}else{
			return "Error while add_crime";
		}
	}else{
		return "Error while preparing add_crime";
	}
} 


if (array_key_exists("longitude", $post_body) && 
	array_key_exists("latitude", $post_body) &&
	array_key_exists("title", $post_body) &&
	array_key_exists("date", $post_body) &&
	array_key_exists("report", $post_body) &&
	array_key_exists("category_id", $post_body) ) 
{

	$longitude = $post_body["longitude"];
	$latitude = $post_body["latitude"];
	$title = $post_body["title"];
	$date = $post_body["date"];
	$report = $post_body["report"];
	$category_id = $post_body["category_id"];
	
	if(!empty(trim($longitude)) && 
	   !empty(trim($latitude)) && 
	   !empty(trim($title)) && 
	   !empty(trim($date)) && 
	   !empty(trim($report)) &&
	   !empty(trim($category_id)) ) 
	{
		$longitude = floatval($longitude);
		$latitude = floatval($latitude);
		$category_id = intval($category_id);
		$user_id = $_SESSION["user_id"];

		if (!preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$date)) {
			response_error("Error in date formating");
		}

		$output = add_crime($conn, $longitude, $latitude, $report, $title, $date, $category_id, $user_id);
		if ($output === True){
			response_success("Crime created");
		}else{
			$error_message = $output;
		}
	}else{
		$error_message = "Some parameters are empty";		
	}
}else{
	$error_message = "Not all crime parameters are set";
}

response_error($error_message);