-- MySQL dump 10.13  Distrib 5.7.30, for Linux (x86_64)
--
-- Host: localhost    Database: criminal_map
-- ------------------------------------------------------
-- Server version	5.7.30-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `criminal_map`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `criminal_map` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `criminal_map`;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'murder'),(2,'robbery'),(3,'rape'),(4,'physical violence'),(5,'uncategorized');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crime_is_category`
--

DROP TABLE IF EXISTS `crime_is_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crime_is_category` (
  `crime_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`crime_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crime_is_category`
--

LOCK TABLES `crime_is_category` WRITE;
/*!40000 ALTER TABLE `crime_is_category` DISABLE KEYS */;
INSERT INTO `crime_is_category` VALUES (15,5),(16,5),(17,5),(18,5),(19,5),(20,5),(21,5),(22,5),(23,5),(24,2),(25,1),(26,1),(27,4),(28,1),(29,4),(30,4),(31,1);
/*!40000 ALTER TABLE `crime_is_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crimes`
--

DROP TABLE IF EXISTS `crimes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crimes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `longitude` double DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `report` text,
  `title` text,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crimes`
--

LOCK TABLES `crimes` WRITE;
/*!40000 ALTER TABLE `crimes` DISABLE KEYS */;
INSERT INTO `crimes` VALUES (15,3.14,3.14,'I saw the devil','1st !!','2020-04-04'),(16,3.14,3.14,'I saw the devil','2st !!','2020-04-04'),(17,3.14,3.14,'I saw the devil','2st !!','2021-04-04'),(18,3.14,3.14,'I saw the devil','34st !!','2021-04-04'),(19,3.14,3.14,'I saw the devil','34st !!','2021-04-04'),(20,4.4444,4.4444,'Example report','Test title','2020-05-22'),(21,4.4444,4.4444,'Example report','Test title','2020-05-22'),(22,4.4444,4.4444,'Example report','Test title','2020-05-22'),(23,4.4444,4.4444,'Example report','Test title','2020-05-22'),(24,22.963791489601135,40.608430566428055,'This is a test crime','Test crime','2020-04-06'),(25,22.988245859742168,40.6017337107569,'Crime number 2','Test 2','2020-04-12'),(26,22.95306634157896,40.58226475421497,'Test','Crime test 3','2020-04-13'),(27,22.97857280820608,40.589911966614814,'jasdja','Test 4','2020-04-06'),(28,22.986413910984993,40.58157418576756,'jsfh','Test 5','2020-04-04'),(29,22.958763688802716,40.62550910426239,'stupa','skatat','2020-04-13'),(30,22.955068610608574,40.60725919329062,'fc. v\n','ffccc','2020-04-07'),(31,22.96613406389952,40.598157571099996,'a kuder was done here','Murder: here','2020-04-14');
/*!40000 ALTER TABLE `crimes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_created_crime`
--

DROP TABLE IF EXISTS `user_created_crime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_created_crime` (
  `user_id` int(11) NOT NULL,
  `crime_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`crime_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_created_crime`
--

LOCK TABLES `user_created_crime` WRITE;
/*!40000 ALTER TABLE `user_created_crime` DISABLE KEYS */;
INSERT INTO `user_created_crime` VALUES (1,20),(1,21),(1,22),(1,23),(1,29),(1,30),(1,31),(2,15),(2,16),(2,17),(2,18),(2,19),(3,24),(3,25),(3,26),(3,27),(3,28);
/*!40000 ALTER TABLE `user_created_crime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','1'),(2,'admin2','2'),(3,'test','test'),(4,'glalal','123');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-26 17:49:33
